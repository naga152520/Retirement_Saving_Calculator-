const RetirementCalculatorPage = require("../pageobjects/retirementcalculator.page")
const retirementCalcPage = new RetirementCalculatorPage()

describe('Retirement Savings Calculator', () => {
    before(() => {
        browser.url('https://www.securian.com/insights-tools/retirement-calculator.html');
        $('#current-age').waitForExist({ timeout: 10000, timeoutMsg: 'Expected #current-age to be present' });
    });

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    it('should update default calculator values', async () => {
        try {
            // Update initial values
            await retirementCalcPage.setCurrentAge('45')
            await retirementCalcPage.setRetirementAge('65')
            const currentIncomeInput = await retirementCalcPage.setAndGetCurrentIncome('120000')
            await retirementCalcPage.setSpouseIncome('75000');
            await retirementCalcPage.setCurrentTotalSavings('500000');
            await retirementCalcPage.setCurrentAnnualSavings('10');// Set spouse income
            await retirementCalcPage.setIncreaseAnnualSavings('2');
            const socialSecurityInput = await retirementCalcPage.toggleSocialSecurityToYes();// Check if Social Security Yes is selected, then click Married radio button and set Social Security override amount

            if (await socialSecurityInput.isSelected()) {

                await socialSecurityInput.scrollIntoView()
                await sleep(1000)
                const maritalStatusRadio = $('label[for="married"]');

                // Click the element using JavaScript to bypass the interception
                await maritalStatusRadio.click()

                // Wait for the element to be clickable
                await retirementCalcPage.setSocialSecurityOverride('4000')
            }

            // Click Calculate button
            await $('button[class="dsg-btn-primary btn-block"][data-tag-id="submit"]').click();

            // Wait for the result to be displayed
            const result = $('#calculator-results-container');
            await result.waitForDisplayed({ timeout: 10000 });

            // Retrieve and log the updated values for debugging
            const updatedCurrentAge = await $('#current-age').getValue();
            const updatedRetirementAge = await $('#retirement-age').getValue();
            const updatedYearlyIncome = await currentIncomeInput.getValue();

            // Log the retrieved values for debugging
            console.log('Updated values:', updatedCurrentAge, updatedRetirementAge, updatedYearlyIncome);

            // Assert the updated values
            expect(updatedCurrentAge).toBe('45');
            expect(updatedRetirementAge).toBe('65');
            expect(updatedYearlyIncome).toBe('$120,000');
        } catch (error) {
            // Log any errors for debugging
            console.error('Error occurred:', error);
            throw error; // Re-throw the error to mark the test as failed
        }
    });
});          // Update initial values
