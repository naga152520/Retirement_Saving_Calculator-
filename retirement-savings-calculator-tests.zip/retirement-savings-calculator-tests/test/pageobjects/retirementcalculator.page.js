const { browser } = require('@wdio/globals')
/**
 * main page object containing all methods, selectors and functionality
 * that is shared across all page objects
 */
module.exports = class RetirementCalculatorPage {

    async clearAndSetValue(element, value) {
        await element.click(); // Click to focus
        await element.setValue(''); // Clear existing value if any
        await element.setValue(value); // Set new value
    }
    /**
     * Opens a sub page of the page
     * @param path path of the sub page (e.g. /path/to/page.html)
     */
    open (path) {
        return browser.url(`https://the-internet.herokuapp.com/${path}`)
    }

    async setAndGetCurrentIncome(currentIncome) {
        const currentIncomeInput = $('#current-income');
        await this.clearAndSetValue(currentIncomeInput, currentIncome);
        return await $('#current-income')
    }

    async setCurrentAge(currentAge) {
        const currentAgeInput = $('#current-age');
        await this.clearAndSetValue(currentAgeInput, currentAge);
    }

    async setRetirementAge(retirementAge) {
        const retirementAgeInput = $('#retirement-age');
        await this.clearAndSetValue(retirementAgeInput, retirementAge);
    }

    async setSpouseIncome(income) {
        const spouseIncomeInput = $('#spouse-income');
        await this.clearAndSetValue(spouseIncomeInput, income);
    }

    async setCurrentTotalSavings(totalSavings) {
        const currentTotalSavingsInput = $('#current-total-savings');
        await this.clearAndSetValue(currentTotalSavingsInput, totalSavings);
    }

    async setCurrentAnnualSavings(annualSavings) {
        const currentAnnualSavingsInput = $('#current-annual-savings');
        await this.clearAndSetValue(currentAnnualSavingsInput, annualSavings);
    }

    async setIncreaseAnnualSavings(increaseRate) {
        const increaseAnnualSavingsInput = $('#savings-increase-rate');
        await this.clearAndSetValue(increaseAnnualSavingsInput, increaseRate);
    }

    async  toggleSocialSecurityToYes() {
        const yesSocialSecurityLabel = $('label[for="yes-social-benefits"]');
        await yesSocialSecurityLabel.click();
        return yesSocialSecurityLabel
        // Optionally, set related fields here after clicking the label
    }

    async setSocialSecurityOverride(value) {
        // Wait for the element to be clickable
        const socialSecurityOverrideInput = $('#social-security-override');
        await socialSecurityOverrideInput.waitForClickable({ timeout: 5000 }); // Adjust timeout as needed

        // Clear and set value
        await this.clearAndSetValue(socialSecurityOverrideInput, value);
    }





}
